<footer class="footer">
    <div class="container-fluid">
        <nav class="float-left">

        </nav>
        <div class="copyright float-right">
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script>, made with <i class="material-icons">favorite</i> by
            <a href="#" target="_blank">Propress</a>
        </div>
    </div>
</footer>
