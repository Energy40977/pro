<div class="col-lg-2 col-md-3 primary-sidebar sticky-sidebar sidebar-left order-2 order-md-1">
    <!-- Widget Weather -->

    <div class="sidebar-widget widget-weather border-radius-10 bg-white mb-30 mt-55">
        <a class="weatherwidget-io" href="https://forecast7.com/tr/40d4149d87/baku/" data-label_1="BAKI" data-icons="Climacons Animated" data-mode="Current" data-days="3" data-theme="pure" >BAKI</a>

    </div>
    <!-- Widget Categories -->
    <!-- Widget Categories -->
    <div class="sidebar-widget widget_categories border-radius-10 bg-white mb-30">
        <div class="widget-header position-relative mb-15">
            <h5 class="widget-title"><strong></strong></h5>
            <img src="{{asset('site/images/banner.jpg')}}" alt="">
        </div>

    </div>
</div>
