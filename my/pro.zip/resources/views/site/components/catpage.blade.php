<div class="col-lg-8 col-md-12">
    <!-- Featured posts -->

    <!--Videos-->
    <div class="latest-post">
        <div class="widget-header position-relative mb-30">
            <div class="row">
                <div class="col-7">
                    <h4 class="widget-title mb-0"><span>Xəbərlər</span></h4>
                </div>

            </div>
        </div>
        @include('site.components.categorylast')
    </div>
    <div class="row">
        <div class="col-12 text-center mt-50 mb-50">
            <a href="#">
                <img class="border-radius-10 d-inline" src="{{asset('site/images/imgs-ads.jpg')}}" alt="post-slider">
            </a>
        </div>
    </div>
</div>
